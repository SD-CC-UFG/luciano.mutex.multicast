package com.peak.salut.Callbacks;

import com.peak.salut.SalutDevice;

public interface SalutDeviceCallback {
    void call(SalutDevice device);
}
